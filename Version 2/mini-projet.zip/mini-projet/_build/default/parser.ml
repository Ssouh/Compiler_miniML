
module MenhirBasics = struct
  
  exception Error
  
  type token = 
    | UMinusToken
    | TrueToken
    | ThenToken
    | StarToken
    | SlashToken
    | SequenceToken
    | RightParenthesisToken
    | RefToken
    | RecToken
    | PlusToken
    | OrToken
    | NumberToken of (
# 6 "parser.mly"
       (int)
# 22 "parser.ml"
  )
    | MinusToken
    | LetToken
    | LesserToken
    | LesserEqualToken
    | LeftParenthesisToken
    | InToken
    | IfToken
    | IdentToken of (
# 7 "parser.mly"
       (string)
# 34 "parser.ml"
  )
    | GreaterToken
    | GreaterEqualToken
    | FunctionToken
    | FalseToken
    | EqualToken
    | ElseToken
    | EOF
    | DifferentToken
    | DerefToken
    | BodyToken
    | AssignToken
    | AndToken
  
end

include MenhirBasics

let _eRR =
  MenhirBasics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState62
  | MenhirState58
  | MenhirState55
  | MenhirState52
  | MenhirState50
  | MenhirState47
  | MenhirState45
  | MenhirState43
  | MenhirState41
  | MenhirState39
  | MenhirState37
  | MenhirState35
  | MenhirState33
  | MenhirState31
  | MenhirState29
  | MenhirState27
  | MenhirState25
  | MenhirState23
  | MenhirState21
  | MenhirState18
  | MenhirState16
  | MenhirState12
  | MenhirState11
  | MenhirState10
  | MenhirState7
  | MenhirState5
  | MenhirState2
  | MenhirState0

# 1 "parser.mly"
  
open Ast

# 97 "parser.ml"

let rec _menhir_run21 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 102 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState21 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState21 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState21

and _menhir_run23 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 140 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState23

and _menhir_run25 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 178 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState25 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState25 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState25
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState25

and _menhir_run27 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 216 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState27
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState27

and _menhir_run29 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 254 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState29

and _menhir_run31 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 292 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState31

and _menhir_run33 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 330 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState33

and _menhir_run35 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 368 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState35 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState35 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState35
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState35

and _menhir_run37 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 406 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState37

and _menhir_run39 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 444 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState39
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState39

and _menhir_run41 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 482 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState41

and _menhir_run43 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 520 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState43

and _menhir_run47 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 558 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState47
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState47

and _menhir_run45 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 46 "parser.mly"
      (Ast.ast)
# 596 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState45 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState45 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState45
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState45

and _menhir_goto_expr : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 46 "parser.mly"
      (Ast.ast)
# 634 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState18 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 645 "parser.ml"
        ))) = _menhir_stack in
        let _1 = () in
        let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 651 "parser.ml"
        ) = 
# 94 "parser.mly"
                                                                     (ReadNode e)
# 655 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
    | MenhirState16 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), (n : (
# 7 "parser.mly"
       (string)
# 696 "parser.ml"
            ))), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 700 "parser.ml"
            ))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 707 "parser.ml"
            ) = 
# 85 "parser.mly"
                                                                     (FunctionNode (n,e))
# 711 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState21 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 726 "parser.ml"
        ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 730 "parser.ml"
        ))) = _menhir_stack in
        let _2 = () in
        let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 736 "parser.ml"
        ) = 
# 106 "parser.mly"
                                                                     (BinaryNode (Multiply,e1,e2))
# 740 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 749 "parser.ml"
        ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 753 "parser.ml"
        ))) = _menhir_stack in
        let _2 = () in
        let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 759 "parser.ml"
        ) = 
# 107 "parser.mly"
                                                                     (BinaryNode (Divide,e1,e2))
# 763 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
    | MenhirState25 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 804 "parser.ml"
            ))), _, (p : (
# 46 "parser.mly"
      (Ast.ast)
# 808 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 814 "parser.ml"
            ) = 
# 89 "parser.mly"
                                                                     (SequenceNode(e,p))
# 818 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState27 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | GreaterEqualToken | GreaterToken | InToken | LesserEqualToken | LesserToken | MinusToken | OrToken | PlusToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 841 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 845 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 851 "parser.ml"
            ) = 
# 104 "parser.mly"
                                                                     (BinaryNode (Add,e1,e2))
# 855 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken | EOF | ElseToken | InToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 898 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 902 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 908 "parser.ml"
            ) = 
# 103 "parser.mly"
                                                                     (BinaryNode (Or,e1,e2))
# 912 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState31 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | GreaterEqualToken | GreaterToken | InToken | LesserEqualToken | LesserToken | MinusToken | OrToken | PlusToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 935 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 939 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 945 "parser.ml"
            ) = 
# 105 "parser.mly"
                                                                     (BinaryNode (Substract,e1,e2))
# 949 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState33 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 976 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 980 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 986 "parser.ml"
            ) = 
# 98 "parser.mly"
                                                                     (BinaryNode (Lesser,e1,e2))
# 990 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState35 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1017 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1021 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1027 "parser.ml"
            ) = 
# 100 "parser.mly"
                                                                     (BinaryNode (LesserEqual,e1,e2))
# 1031 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState37 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1058 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1062 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1068 "parser.ml"
            ) = 
# 99 "parser.mly"
                                                                     (BinaryNode (Greater,e1,e2))
# 1072 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1099 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1103 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1109 "parser.ml"
            ) = 
# 101 "parser.mly"
                                                                     (BinaryNode (GreaterEqual,e1,e2))
# 1113 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState41 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1148 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1152 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1158 "parser.ml"
            ) = 
# 96 "parser.mly"
                                                                     (BinaryNode (Equal,e1,e2))
# 1162 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1197 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1201 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1207 "parser.ml"
            ) = 
# 97 "parser.mly"
                                                                     (BinaryNode (Different,e1,e2))
# 1211 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState45 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken | EOF | ElseToken | InToken | OrToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1252 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1256 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1262 "parser.ml"
            ) = 
# 102 "parser.mly"
                                                                     (BinaryNode (And,e1,e2))
# 1266 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState47 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | SequenceToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (i : (
# 46 "parser.mly"
      (Ast.ast)
# 1311 "parser.ml"
            ))), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 1315 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1321 "parser.ml"
            ) = 
# 95 "parser.mly"
                                                                     (WriteNode(i,e))
# 1325 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState12 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState50
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState50)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | ElseToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState52 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState52 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState52
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState52)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState52 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (c : (
# 46 "parser.mly"
      (Ast.ast)
# 1516 "parser.ml"
            ))), _, (t : (
# 46 "parser.mly"
      (Ast.ast)
# 1520 "parser.ml"
            ))), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 1524 "parser.ml"
            ))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1532 "parser.ml"
            ) = 
# 88 "parser.mly"
                                                                     (IfthenelseNode (c,t,e))
# 1536 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState11 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | RightParenthesisToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState55 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState55 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState55
            | AndToken | AssignToken | DifferentToken | EOF | ElseToken | EqualToken | GreaterEqualToken | GreaterToken | InToken | LesserEqualToken | LesserToken | OrToken | PlusToken | RightParenthesisToken | SequenceToken | SlashToken | StarToken | ThenToken ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let ((_menhir_stack, _menhir_s), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 1606 "parser.ml"
                ))) = _menhir_stack in
                let _3 = () in
                let _1 = () in
                let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1613 "parser.ml"
                ) = 
# 91 "parser.mly"
                                                                     (e)
# 1617 "parser.ml"
                 in
                _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState55)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState55 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), _, (f : (
# 46 "parser.mly"
      (Ast.ast)
# 1674 "parser.ml"
            ))), _, (p : (
# 46 "parser.mly"
      (Ast.ast)
# 1678 "parser.ml"
            ))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1685 "parser.ml"
            ) = 
# 90 "parser.mly"
                                                                     (CallNode (f,p))
# 1689 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState10 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | InToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState58 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState58 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState58
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState58)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState58 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), (n : (
# 7 "parser.mly"
       (string)
# 1808 "parser.ml"
            ))), _, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1812 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1816 "parser.ml"
            ))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1824 "parser.ml"
            ) = 
# 86 "parser.mly"
                                                                     (LetNode (n,e1,e2))
# 1828 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState7 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 1843 "parser.ml"
        ))) = _menhir_stack in
        let _1 = () in
        let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1849 "parser.ml"
        ) = 
# 92 "parser.mly"
                                                                     (UnaryNode (Negate,e))
# 1853 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
    | MenhirState5 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | InToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState62
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState62)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState62 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | EOF | ElseToken | InToken | RightParenthesisToken | ThenToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), (n : (
# 7 "parser.mly"
       (string)
# 1966 "parser.ml"
            ))), _, (e1 : (
# 46 "parser.mly"
      (Ast.ast)
# 1970 "parser.ml"
            ))), _, (e2 : (
# 46 "parser.mly"
      (Ast.ast)
# 1974 "parser.ml"
            ))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 1982 "parser.ml"
            ) = 
# 87 "parser.mly"
                                                                     (LetrecNode (n,e1,e2))
# 1986 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState2 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _, (e : (
# 46 "parser.mly"
      (Ast.ast)
# 2001 "parser.ml"
        ))) = _menhir_stack in
        let _1 = () in
        let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 2007 "parser.ml"
        ) = 
# 93 "parser.mly"
                                                                     (RefNode e)
# 2011 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AndToken ->
            _menhir_run45 _menhir_env (Obj.magic _menhir_stack)
        | AssignToken ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack)
        | DifferentToken ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack)
        | EOF ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (a : (
# 46 "parser.mly"
      (Ast.ast)
# 2031 "parser.ml"
            ))) = _menhir_stack in
            let _2 = () in
            let _v : (
# 49 "parser.mly"
       (Ast.ast)
# 2037 "parser.ml"
            ) = 
# 82 "parser.mly"
                      (a)
# 2041 "parser.ml"
             in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_1 : (
# 49 "parser.mly"
       (Ast.ast)
# 2048 "parser.ml"
            )) = _v in
            Obj.magic _1
        | EqualToken ->
            _menhir_run41 _menhir_env (Obj.magic _menhir_stack)
        | GreaterEqualToken ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack)
        | GreaterToken ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack)
        | LesserEqualToken ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack)
        | LesserToken ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack)
        | MinusToken ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack)
        | OrToken ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack)
        | PlusToken ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack)
        | SequenceToken ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack)
        | SlashToken ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack)
        | StarToken ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState62 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState58 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState55 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState52 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState47 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState45 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState41 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState37 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState35 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState33 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState31 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState27 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState25 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState21 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState18 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState16 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState12 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState11 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState10 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState7 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState5 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState2 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 2203 "parser.ml"
    ) = 
# 110 "parser.mly"
                                                                     (TrueNode)
# 2207 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState2 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState2 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState2
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState2

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | IdentToken _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | EqualToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState5 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState5
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState5)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run6 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 6 "parser.mly"
       (int)
# 2307 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (
# 6 "parser.mly"
       (int)
# 2315 "parser.ml"
    )) = _v in
    let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 2320 "parser.ml"
    ) = 
# 109 "parser.mly"
                                                                     (IntegerNode i)
# 2324 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState7

and _menhir_run8 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | IdentToken _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | EqualToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState10
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState10)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState11

and _menhir_run12 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState12
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState12

and _menhir_run13 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 7 "parser.mly"
       (string)
# 2494 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (n : (
# 7 "parser.mly"
       (string)
# 2502 "parser.ml"
    )) = _v in
    let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 2507 "parser.ml"
    ) = 
# 108 "parser.mly"
                                                                     (AccessNode n)
# 2511 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | IdentToken _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | BodyToken ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DerefToken ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | FalseToken ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | FunctionToken ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | IdentToken _v ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState16 _v
            | IfToken ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | LeftParenthesisToken ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | LetToken ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | MinusToken ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | NumberToken _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState16 _v
            | RecToken ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | RefToken ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | TrueToken ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState16
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState16)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run17 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (
# 46 "parser.mly"
      (Ast.ast)
# 2581 "parser.ml"
    ) = 
# 111 "parser.mly"
                                                                     (FalseNode)
# 2585 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run18 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState18 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState18 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState18

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and main : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 49 "parser.mly"
       (Ast.ast)
# 2639 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = let _tok = Obj.magic () in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    } in
    Obj.magic (let _menhir_stack = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DerefToken ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FalseToken ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FunctionToken ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | IdentToken _v ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | IfToken ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LeftParenthesisToken ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LetToken ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | MinusToken ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | NumberToken _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | RecToken ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | RefToken ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | TrueToken ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0)

# 269 "<standard.mly>"
  

# 2685 "parser.ml"
